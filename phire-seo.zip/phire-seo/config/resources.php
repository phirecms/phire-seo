<?php

return [
    'seo' => [
        'index'
    ]
];