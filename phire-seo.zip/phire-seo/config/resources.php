<?php

return [
    'seo' => [
        'index',
        'analysis',
        'json'
    ]
];